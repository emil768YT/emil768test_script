@echo off
powershell.exe -NoProfile -File "%~dp0start-spotify.ps1"
