param(
    [ValidateSet('Serve', 'Check', 'Stop')][string]$Mode = 'Serve',
    [int]$Port = 43821
)
$ErrorActionPreference = 'Stop'
$ServiceName = 'emil768.spotify.bridge'
$BaseUrl = 'http://127.0.0.1:' + $Port
if ($Mode -eq 'Stop') {
    $pair = Invoke-RestMethod -Method Post -Uri ($BaseUrl + '/pair') -ContentType 'application/json' -Body '{"client":"emil768.roblox"}'
    Invoke-RestMethod -Method Post -Uri ($BaseUrl + '/shutdown') -ContentType 'application/json' -Headers @{Authorization = 'Bearer ' + $pair.token} -Body '{}' | Out-Null
    Write-Output 'Spotify Bridge stopped.'
    exit
}
Add-Type -AssemblyName System.Runtime.WindowsRuntime
Add-Type -AssemblyName System.Drawing
$ManagerType = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionManager, Windows.Media.Control, ContentType=WindowsRuntime]
$PropertiesType = [Windows.Media.Control.GlobalSystemMediaTransportControlsSessionMediaProperties, Windows.Media.Control, ContentType=WindowsRuntime]
$StreamType = [Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType=WindowsRuntime]
$AsTask = [System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and $_.GetGenericArguments().Count -eq 1 -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' } | Select-Object -First 1
$ConvertStream = [System.IO.WindowsRuntimeStreamExtensions].GetMethods() | Where-Object { $_.Name -eq 'AsStream' -and $_.GetParameters().Count -eq 1 } | Select-Object -First 1
function Await-MediaOperation($Operation, [Type]$ResultType) {
    $task = $AsTask.MakeGenericMethod($ResultType).Invoke($null, @($Operation))
    if (-not $task.Wait(4000)) { throw 'Media operation timed out.' }
    return $task.Result
}
$Manager = Await-MediaOperation ($ManagerType::RequestAsync()) $ManagerType
$script:CoverBytes = [byte[]]@()
$script:CoverVersion = ''
$script:CoverKey = ''
function Get-SpotifySession {
    foreach ($session in $Manager.GetSessions()) {
        if ($session.SourceAppUserModelId -match '(?i)(^Spotify\.exe$|^SpotifyAB\.SpotifyMusic_)') { return $session }
    }
    return $null
}
function Update-Cover($Properties, [string]$Key) {
    if ($script:CoverKey -eq $Key) { return }
    $script:CoverKey = $Key
    $script:CoverBytes = [byte[]]@()
    $script:CoverVersion = ''
    if (-not $Properties.Thumbnail) { return }
    $stream = $null
    $netInput = $null
    try {
        $stream = Await-MediaOperation ($Properties.Thumbnail.OpenReadAsync()) $StreamType
        $netInput = $ConvertStream.Invoke($null, @($stream))
        if ($netInput.Length -le 0 -or $netInput.Length -gt 2097152) { return }
        $memory = [System.IO.MemoryStream]::new()
        $netInput.CopyTo($memory)
        $memory.Position = 0
        $image = $null
        $bitmap = $null
        $graphics = $null
        $output = $null
        try {
            $image = [System.Drawing.Image]::FromStream($memory)
            $bitmap = [System.Drawing.Bitmap]::new(128, 128)
            $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
            $graphics.DrawImage($image, 0, 0, 128, 128)
            $output = [System.IO.MemoryStream]::new()
            $bitmap.Save($output, [System.Drawing.Imaging.ImageFormat]::Png)
            $script:CoverBytes = $output.ToArray()
            $sha = [System.Security.Cryptography.SHA256]::Create()
            try { $script:CoverVersion = ([BitConverter]::ToString($sha.ComputeHash($script:CoverBytes))).Replace('-', '').ToLowerInvariant() } finally { $sha.Dispose() }
        } finally {
            if ($graphics) { $graphics.Dispose() }
            if ($bitmap) { $bitmap.Dispose() }
            if ($image) { $image.Dispose() }
            if ($output) { $output.Dispose() }
            $memory.Dispose()
        }
    } catch {
        $script:CoverKey = ''
        $script:CoverError = $_.Exception.Message
    } finally {
        if ($netInput) { $netInput.Dispose() }
    }
}
function Get-SpotifyState {
    $session = Get-SpotifySession
    if (-not $session) {
        $script:CoverBytes = [byte[]]@()
        $script:CoverVersion = ''
        $script:CoverKey = ''
        return @{service = $ServiceName; version = 1; available = $false}
    }
    $properties = Await-MediaOperation ($session.TryGetMediaPropertiesAsync()) $PropertiesType
    $info = $session.GetPlaybackInfo()
    $timeline = $session.GetTimelineProperties()
    $playing = $info.PlaybackStatus.ToString() -eq 'Playing'
    $duration = [Math]::Max(0, ($timeline.EndTime - $timeline.StartTime).TotalMilliseconds)
    $position = [Math]::Max(0, ($timeline.Position - $timeline.StartTime).TotalMilliseconds)
    if ($playing -and $duration -gt 0) {
        $delta = ([DateTimeOffset]::UtcNow - $timeline.LastUpdatedTime).TotalMilliseconds
        $position += [Math]::Max(0, $delta)
    }
    if ($duration -gt 0) { $position = [Math]::Min($position, $duration) }
    $key = [string]$session.SourceAppUserModelId + '|' + $properties.Title + '|' + $properties.Artist + '|' + $properties.AlbumTitle
    Update-Cover $properties $key
    return @{
        service = $ServiceName; version = 1; available = $true; playing = $playing
        title = [string]$properties.Title; artist = [string]$properties.Artist; album = [string]$properties.AlbumTitle
        position_ms = [Math]::Round($position); duration_ms = [Math]::Round($duration)
        can_toggle = [bool]$info.Controls.IsPlayPauseToggleEnabled
        can_previous = [bool]$info.Controls.IsPreviousEnabled; can_next = [bool]$info.Controls.IsNextEnabled
        cover_version = $script:CoverVersion
    }
}
if ($Mode -eq 'Check') {
    $state = Get-SpotifyState
    @{service = $state.service; available = $state.available; coverBytes = $script:CoverBytes.Length; duration_ms = $state.duration_ms; cover_error = $script:CoverError} | ConvertTo-Json -Compress
    exit
}
function Read-LocalRequest($Client) {
    $Client.ReceiveTimeout = 2000
    $Client.SendTimeout = 2000
    $stream = $Client.GetStream()
    $bytes = [System.Collections.Generic.List[byte]]::new()
    while ($bytes.Count -lt 8192) {
        $value = $stream.ReadByte()
        if ($value -lt 0) { throw 'Connection closed.' }
        $bytes.Add([byte]$value)
        $count = $bytes.Count
        if ($count -ge 4 -and $bytes[$count-4] -eq 13 -and $bytes[$count-3] -eq 10 -and $bytes[$count-2] -eq 13 -and $bytes[$count-1] -eq 10) { break }
    }
    if ($bytes.Count -ge 8192) { throw 'Headers too large.' }
    $lines = [Text.Encoding]::ASCII.GetString($bytes.ToArray()) -split "`r`n"
    $first = $lines[0] -split ' '
    if ($first.Count -ne 3 -or $first[0] -notin @('GET','POST') -or $first[2] -ne 'HTTP/1.1') { throw 'Invalid request.' }
    $headers = @{}
    foreach ($line in $lines | Select-Object -Skip 1) {
        if ($line -eq '') { continue }
        $index = $line.IndexOf(':')
        if ($index -lt 1) { throw 'Invalid header.' }
        $headers[$line.Substring(0,$index).ToLowerInvariant()] = $line.Substring($index+1).Trim()
    }
    $length = 0
    if ($headers.ContainsKey('content-length') -and -not [int]::TryParse($headers['content-length'], [ref]$length)) { throw 'Invalid length.' }
    if ($length -lt 0 -or $length -gt 4096 -or $headers.ContainsKey('transfer-encoding')) { throw 'Invalid body.' }
    $body = New-Object byte[] $length
    $offset = 0
    while ($offset -lt $length) {
        $read = $stream.Read($body, $offset, $length-$offset)
        if ($read -le 0) { throw 'Incomplete body.' }
        $offset += $read
    }
    return @{method = $first[0]; path = $first[1]; headers = $headers; body = [Text.Encoding]::UTF8.GetString($body)}
}
function Send-LocalResponse($Client, [int]$Status, $Body, [string]$ContentType = 'application/json') {
    if ($Body -is [byte[]]) { $payload = $Body } else { $payload = [Text.Encoding]::UTF8.GetBytes(($Body | ConvertTo-Json -Depth 6 -Compress)) }
    $header = [Text.Encoding]::ASCII.GetBytes("HTTP/1.1 $Status Response`r`nContent-Type: $ContentType`r`nContent-Length: $($payload.Length)`r`nConnection: close`r`nCache-Control: no-store`r`n`r`n")
    $stream = $Client.GetStream()
    $stream.Write($header, 0, $header.Length)
    $stream.Write($payload, 0, $payload.Length)
    $stream.Flush()
}
$Token = [Guid]::NewGuid().ToString('N') + [Guid]::NewGuid().ToString('N')
$Listener = [Net.Sockets.TcpListener]::new([Net.IPAddress]::Loopback, $Port)
$Listener.Start()
Write-Output ('Spotify Bridge ready on ' + $BaseUrl)
try {
    $running = $true
    while ($running) {
        $client = $Listener.AcceptTcpClient()
        try {
            $request = Read-LocalRequest $client
            if ($request.headers.ContainsKey('origin') -or $request.headers['host'] -ne "127.0.0.1:$Port") { Send-LocalResponse $client 403 @{error='local_client_required'}; continue }
            if ($request.method -eq 'GET' -and $request.path -eq '/health') { Send-LocalResponse $client 200 @{service=$ServiceName;version=1}; continue }
            if ($request.method -eq 'POST' -and $request.path -eq '/pair') {
                if ($request.headers['content-type'] -notmatch '^application/json') { Send-LocalResponse $client 415 @{error='json_required'}; continue }
                $data = $request.body | ConvertFrom-Json
                if ($data.client -ne 'emil768.roblox') { Send-LocalResponse $client 400 @{error='invalid_client'}; continue }
                Send-LocalResponse $client 200 @{service=$ServiceName;version=1;token=$Token}
                continue
            }
            if ($request.headers['authorization'] -cne ('Bearer ' + $Token)) { Send-LocalResponse $client 401 @{error='not_paired'}; continue }
            if ($request.method -eq 'GET' -and $request.path -eq '/state') { Send-LocalResponse $client 200 (Get-SpotifyState); continue }
            if ($request.method -eq 'GET' -and $request.path -eq '/cover') {
                if ($script:CoverBytes.Length -gt 0) { Send-LocalResponse $client 200 $script:CoverBytes 'image/png' } else { Send-LocalResponse $client 404 @{error='no_cover'} }
                continue
            }
            if ($request.method -eq 'POST' -and $request.path -eq '/shutdown') {
                Send-LocalResponse $client 200 @{ok=$true}
                $running = $false
                continue
            }
            if ($request.method -eq 'POST' -and $request.path -eq '/command') {
                if ($request.headers['content-type'] -notmatch '^application/json') { Send-LocalResponse $client 415 @{error='json_required'}; continue }
                $data = $request.body | ConvertFrom-Json
                if ($data.action -notin @('toggle','previous','next')) { Send-LocalResponse $client 400 @{error='unknown_action'}; continue }
                $session = Get-SpotifySession
                if (-not $session) { Send-LocalResponse $client 409 @{error='spotify_not_running'}; continue }
                $controls = $session.GetPlaybackInfo().Controls
                $operation = $null
                switch ($data.action) {
                    'toggle' { if ($controls.IsPlayPauseToggleEnabled) { $operation = $session.TryTogglePlayPauseAsync() } }
                    'previous' { if ($controls.IsPreviousEnabled) { $operation = $session.TrySkipPreviousAsync() } }
                    'next' { if ($controls.IsNextEnabled) { $operation = $session.TrySkipNextAsync() } }
                }
                if (-not $operation) { Send-LocalResponse $client 409 @{error='control_unavailable'}; continue }
                $accepted = Await-MediaOperation $operation ([bool])
                if ($accepted) { Send-LocalResponse $client 200 @{ok=$true} } else { Send-LocalResponse $client 409 @{error='control_rejected'} }
                continue
            }
            Send-LocalResponse $client 404 @{error='not_found'}
        } catch {
            try { Send-LocalResponse $client 500 @{error='bridge_error'} } catch {}
        } finally { $client.Dispose() }
    }
} finally { $Listener.Stop() }

