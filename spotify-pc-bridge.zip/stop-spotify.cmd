@echo off
powershell.exe -NoProfile -File "%~dp0spotify-bridge.ps1" -Mode Stop
