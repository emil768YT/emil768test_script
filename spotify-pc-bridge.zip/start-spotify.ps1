$ErrorActionPreference = 'Stop'
$scriptFile = Join-Path $PSScriptRoot 'spotify-bridge.ps1'
try {
    $health = Invoke-RestMethod -Uri 'http://127.0.0.1:43821/health' -TimeoutSec 2
    if ($health.service -eq 'emil768.spotify.bridge') { Write-Output 'Spotify Bridge is already running.'; exit }
} catch {}
Start-Process -FilePath "$env:SystemRoot\System32\WindowsPowerShell\v1.0\powershell.exe" -WindowStyle Hidden -ArgumentList @('-NoProfile', '-NonInteractive', '-File', ('"' + $scriptFile + '"'))
Write-Output 'Spotify Bridge started. Open Spotify on this PC.'
